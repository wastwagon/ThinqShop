<?php
/**
 * Order Confirmation Page
 * ThinQShopping Platform
 */

require_once __DIR__ . '/../../../includes/auth-check.php';
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../includes/functions.php';

$orderNumber = $_GET['order'] ?? '';

if (empty($orderNumber)) {
    redirect('/user/dashboard.php', 'Invalid order reference.', 'danger');
}

$db = new Database();
$conn = $db->getConnection();
$userId = $_SESSION['user_id'];

// Get order details
$stmt = $conn->prepare("
    SELECT o.*, a.*
    FROM orders o
    LEFT JOIN addresses a ON o.shipping_address_id = a.id
    WHERE o.order_number = ? AND o.user_id = ?
");
$stmt->execute([$orderNumber, $userId]);
$order = $stmt->fetch();

if (!$order) {
    redirect('/user/dashboard.php', 'Order not found.', 'danger');
}

// Get order items
$stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt->execute([$order['id']]);
$orderItems = $stmt->fetchAll();

// Get order tracking
$stmt = $conn->prepare("SELECT * FROM order_tracking WHERE order_id = ? ORDER BY created_at DESC");
$stmt->execute([$order['id']]);
$trackingHistory = $stmt->fetchAll();

$pageTitle = 'Order Confirmation - ' . APP_NAME;
include __DIR__ . '/../../../includes/header.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <!-- Success Message -->
            <div class="alert alert-success text-center">
                <i class="fas fa-check-circle fa-3x mb-3"></i>
                <h3>Order Confirmed!</h3>
                <p class="mb-0">Thank you for your order. Your order number is <strong><?php echo htmlspecialchars($orderNumber); ?></strong></p>
            </div>
            
            <!-- Order Details -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Order Details</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <strong>Order Number:</strong><br>
                            <?php echo htmlspecialchars($orderNumber); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Order Date:</strong><br>
                            <?php echo date('F d, Y h:i A', strtotime($order['created_at'])); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Status:</strong><br>
                            <span class="badge bg-<?php 
                                echo $order['status'] === 'pending' ? 'warning' : 
                                    ($order['status'] === 'delivered' ? 'success' : 'info'); 
                            ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $order['status'])); ?>
                            </span>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Payment Status:</strong><br>
                            <span class="badge bg-<?php echo $order['payment_status'] === 'success' ? 'success' : 'warning'; ?>">
                                <?php echo ucfirst($order['payment_status']); ?>
                            </span>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Payment Method:</strong><br>
                            <?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Total Amount:</strong><br>
                            <h5 class="text-primary mb-0"><?php echo formatCurrency($order['total']); ?></h5>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Shipping Address -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Shipping Address</h5>
                </div>
                <div class="card-body">
                    <p class="mb-1">
                        <strong><?php echo htmlspecialchars($order['full_name']); ?></strong><br>
                        <?php echo htmlspecialchars($order['street']); ?><br>
                        <?php echo htmlspecialchars($order['city'] . ', ' . $order['region']); ?><br>
                        Phone: <?php echo htmlspecialchars($order['phone']); ?>
                    </p>
                </div>
            </div>
            
            <!-- Order Items -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Order Items</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Variant</th>
                                    <th class="text-center">Quantity</th>
                                    <th class="text-end">Price</th>
                                    <th class="text-end">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orderItems as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><?php echo htmlspecialchars($item['variant_details'] ?? '-'); ?></td>
                                    <td class="text-center"><?php echo $item['quantity']; ?></td>
                                    <td class="text-end"><?php echo formatCurrency($item['price']); ?></td>
                                    <td class="text-end"><?php echo formatCurrency($item['total']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4" class="text-end"><strong>Subtotal:</strong></td>
                                    <td class="text-end"><?php echo formatCurrency($order['subtotal']); ?></td>
                                </tr>
                                <?php if ($order['tax'] > 0): ?>
                                <tr>
                                    <td colspan="4" class="text-end"><strong>VAT:</strong></td>
                                    <td class="text-end"><?php echo formatCurrency($order['tax']); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if ($order['shipping_fee'] > 0): ?>
                                <tr>
                                    <td colspan="4" class="text-end"><strong>Shipping:</strong></td>
                                    <td class="text-end"><?php echo formatCurrency($order['shipping_fee']); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if ($order['discount'] > 0): ?>
                                <tr>
                                    <td colspan="4" class="text-end text-success"><strong>Discount:</strong></td>
                                    <td class="text-end text-success">-<?php echo formatCurrency($order['discount']); ?></td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td colspan="4" class="text-end"><strong>Total:</strong></td>
                                    <td class="text-end"><strong><?php echo formatCurrency($order['total']); ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Order Tracking -->
            <?php if (!empty($trackingHistory)): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Order Tracking</h5>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        <?php foreach ($trackingHistory as $track): ?>
                        <div class="mb-3">
                            <strong><?php echo ucfirst(str_replace('_', ' ', $track['status'])); ?></strong>
                            <small class="text-muted ms-2"><?php 
                                $timeAgo = timeAgo($track['created_at']); 
                                echo $timeAgo ? $timeAgo : date('M d, Y h:i A', strtotime($track['created_at'])); 
                            ?></small>
                            <?php if ($track['notes']): ?>
                                <p class="mb-0 small text-muted"><?php echo htmlspecialchars($track['notes']); ?></p>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Actions -->
            <div class="text-center">
                <a href="<?php echo BASE_URL; ?>/user/orders/view.php?id=<?php echo $order['id']; ?>" 
                   class="btn btn-primary me-2">View Order Details</a>
                <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-outline-primary">Continue Shopping</a>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>

