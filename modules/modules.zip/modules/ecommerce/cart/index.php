<?php
/**
 * Shopping Cart
 * ThinQShopping Platform
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../../../config/constants.php';
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../includes/functions.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

$db = new Database();
$conn = $db->getConnection();

// Use session ID for guest users, user_id for logged in users
if (isLoggedIn()) {
    $userId = $_SESSION['user_id'];
    $sessionId = null;
    $whereClause = "c.user_id = ?";
    $params = [$userId];
} else {
    $userId = null;
    $sessionId = session_id();
    $whereClause = "c.session_id = ?";
    $params = [$sessionId];
}

// Get cart items
try {
    $stmt = $conn->prepare("
        SELECT c.*, p.name, p.price, p.slug, p.stock_quantity, p.images,
               pv.variant_type, pv.variant_value, pv.price_adjust, pv.stock_quantity as variant_stock
        FROM cart c
        LEFT JOIN products p ON c.product_id = p.id
        LEFT JOIN product_variants pv ON c.variant_id = pv.id
        WHERE $whereClause
        ORDER BY c.created_at DESC
    ");
    $stmt->execute($params);
    $cartItems = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Cart query error: " . $e->getMessage());
    $cartItems = [];
}

// Calculate totals
$subtotal = 0;
$itemCount = 0;

foreach ($cartItems as &$item) {
    $itemPrice = $item['price'];
    if ($item['price_adjust']) {
        $itemPrice += floatval($item['price_adjust']);
    }
    $itemTotal = $itemPrice * $item['quantity'];
    $item['item_price'] = $itemPrice;
    $item['item_total'] = $itemTotal;
    $subtotal += $itemTotal;
    $itemCount += $item['quantity'];
    
    // Get product image
    $images = json_decode($item['images'] ?? '[]', true);
    $item['image'] = !empty($images) ? $images[0] : 'assets/images/products/default.jpg';
}

// VAT Rate (default to 0 if not defined)
$vatRate = defined('VAT_RATE') ? VAT_RATE : 0;
$tax = $subtotal * ($vatRate / 100);
$total = $subtotal + $tax;

$pageTitle = 'Shopping Cart - ' . APP_NAME;
include __DIR__ . '/../../../includes/header.php';
?>

<div class="container my-4">
    <h2 class="mb-4">Shopping Cart</h2>
    
    <?php if (empty($cartItems)): ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-shopping-cart fa-4x text-muted mb-3"></i>
                <h4>Your cart is empty</h4>
                <p class="text-muted">Add some products to get started!</p>
                <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-primary">Continue Shopping</a>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-lg-8 mb-4">
                <div class="card">
                    <div class="card-body">
                        <?php foreach ($cartItems as $item): ?>
                            <div class="cart-item row align-items-center py-3 border-bottom">
                                <div class="col-3 col-md-2">
                                    <img src="<?php echo imageUrl($item['image'], 100, 100); ?>" 
                                         alt="<?php echo htmlspecialchars($item['name']); ?>" 
                                         class="img-fluid rounded">
                                </div>
                                <div class="col-9 col-md-5">
                                    <h5 class="mb-1">
                                        <a href="<?php echo BASE_URL; ?>/product-detail.php?slug=<?php echo $item['slug']; ?>" 
                                           class="text-decoration-none">
                                            <?php echo htmlspecialchars($item['name']); ?>
                                        </a>
                                    </h5>
                                    <?php if ($item['variant_type'] && $item['variant_value']): ?>
                                        <small class="text-muted">
                                            <?php echo ucfirst($item['variant_type']); ?>: <?php echo htmlspecialchars($item['variant_value']); ?>
                                        </small>
                                    <?php endif; ?>
                                    <p class="mb-0 mt-1">
                                        <strong><?php echo formatCurrency($item['item_price']); ?></strong>
                                    </p>
                                </div>
                                <div class="col-6 col-md-2 text-center">
                                    <form method="POST" action="update.php" class="d-inline">
                                        <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                        <div class="input-group">
                                            <button type="submit" name="action" value="decrease" class="btn btn-outline-secondary btn-sm">-</button>
                                            <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" 
                                                   min="1" max="<?php echo $item['variant_stock'] ?? $item['stock_quantity']; ?>" 
                                                   class="form-control form-control-sm text-center" readonly>
                                            <button type="submit" name="action" value="increase" class="btn btn-outline-secondary btn-sm">+</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-3 col-md-2 text-end">
                                    <strong><?php echo formatCurrency($item['item_total']); ?></strong>
                                </div>
                                <div class="col-3 col-md-1 text-end">
                                    <form method="POST" action="remove.php" class="d-inline">
                                        <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                        <button type="submit" class="btn btn-link text-danger" onclick="return confirm('Remove this item?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Order Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal (<?php echo $itemCount; ?> item<?php echo $itemCount != 1 ? 's' : ''; ?>)</span>
                            <strong><?php echo formatCurrency($subtotal); ?></strong>
                        </div>
                        <?php if ($vatRate > 0): ?>
                        <div class="d-flex justify-content-between mb-2">
                            <span>VAT (<?php echo $vatRate; ?>%)</span>
                            <strong><?php echo formatCurrency($tax); ?></strong>
                        </div>
                        <?php endif; ?>
                        <hr>
                        <div class="d-flex justify-content-between mb-3">
                            <strong>Total</strong>
                            <strong class="text-primary"><?php echo formatCurrency($total); ?></strong>
                        </div>
                        <a href="<?php echo BASE_URL; ?>/modules/ecommerce/checkout/" class="btn btn-primary btn-lg w-100">
                            Proceed to Checkout
                        </a>
                        <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-outline-secondary w-100 mt-2">
                            Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../../../includes/footer.php'; ?>







