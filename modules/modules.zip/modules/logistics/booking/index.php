<?php
/**
 * Book Parcel/Delivery
 * ThinQShopping Platform
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Force no cache
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

require_once __DIR__ . '/../../../includes/auth-check.php';
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../includes/functions.php';

$db = new Database();
$conn = $db->getConnection();
$userId = $_SESSION['user_id'];
$user = getCurrentUser();

// Get forwarding warehouses (group by to avoid duplicates)
$stmt = $conn->prepare("SELECT * FROM warehouses WHERE warehouse_type = 'forwarding' AND is_active = 1 GROUP BY warehouse_name ORDER BY sort_order ASC, warehouse_name ASC");
$stmt->execute();
$forwardingWarehouses = $stmt->fetchAll();

// Get destination warehouses (group by to avoid duplicates)
$stmt = $conn->prepare("SELECT * FROM warehouses WHERE warehouse_type = 'destination' AND is_active = 1 GROUP BY warehouse_name ORDER BY sort_order ASC, warehouse_name ASC");
$stmt->execute();
$destinationWarehouses = $stmt->fetchAll();

// Load shipping rates from database
$shippingRates = ['sea' => [], 'air' => []];
try {
    $stmt = $conn->prepare("SELECT * FROM shipping_rates WHERE is_active = 1 ORDER BY method_type, sort_order, rate_name");
    $stmt->execute();
    $rates = $stmt->fetchAll();
    
    foreach ($rates as $rate) {
        $methodType = $rate['method_type'];
        // Always display in USD ($) regardless of database currency
        $rateDisplay = '$' . number_format($rate['rate_value'], 2) . '/' . strtoupper($rate['rate_type']);
        
        $shippingRates[$methodType][] = [
            'id' => $rate['rate_id'],
            'name' => $rate['rate_name'],
            'rate' => $rateDisplay,
            'rate_value' => floatval($rate['rate_value']),
            'rate_type' => $rate['rate_type'],
            'duration' => $rate['duration'] ?? '',
            'description' => $rate['description'] ?? ''
        ];
    }
} catch (PDOException $e) {
    error_log("Error loading shipping rates: " . $e->getMessage());
    // Fallback to empty arrays if table doesn't exist yet
}

// Get user addresses (keep for backward compatibility)
$stmt = $conn->prepare("SELECT * FROM addresses WHERE user_id = ? ORDER BY is_default DESC, created_at DESC");
$stmt->execute([$userId]);
$addresses = $stmt->fetchAll();

// Get shipping methods (for overseas shipping) - keep for backward compatibility
$stmt = $conn->query("SELECT * FROM shipping_methods WHERE is_active = 1 ORDER BY sort_order ASC, base_price ASC");
$shippingMethods = $stmt->fetchAll();

// Get shipping settings
$stmt = $conn->query("SELECT setting_key, setting_value FROM shipping_settings");
$settingsData = $stmt->fetchAll();
$shippingSettings = [];
foreach ($settingsData as $setting) {
    $shippingSettings[$setting['setting_key']] = $setting['setting_value'];
}

$errors = [];
$calculatedPrice = 0;
$estimatedDays = 0;
$selectedMethod = null;

// Handle address save (AJAX) - MUST be before ob_start() and any output
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_address_ajax'])) {
    // Clear any output buffers
    while (ob_get_level()) {
        ob_end_clean();
    }
    
    // Set headers
    header('Content-Type: application/json');
    header('Cache-Control: no-cache, must-revalidate');
    
    // Verify CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid security token. Please refresh the page and try again.']);
        exit;
    }
    
    $fullName = sanitize($_POST['full_name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $street = sanitize($_POST['street'] ?? '');
    $city = sanitize($_POST['city'] ?? '');
    $region = sanitize($_POST['region'] ?? '');
    $country = sanitize($_POST['country'] ?? 'Ghana');
    $landmark = sanitize($_POST['landmark'] ?? '');
    $isDefault = isset($_POST['is_default']) ? 1 : 0;
    $addressType = sanitize($_POST['address_type'] ?? 'pickup'); // 'pickup' or 'delivery'
    
    if (empty($fullName) || empty($phone) || empty($street) || empty($city) || empty($region) || empty($country)) {
        echo json_encode(['success' => false, 'message' => 'Please fill all required fields.']);
        exit;
    }
    
    try {
        $conn->beginTransaction();
        
        // If setting as default, unset other defaults
        if ($isDefault) {
            $stmt = $conn->prepare("UPDATE addresses SET is_default = 0 WHERE user_id = ?");
            $stmt->execute([$userId]);
        }
        
        // Insert new address
        $stmt = $conn->prepare("
            INSERT INTO addresses (
                user_id, full_name, phone, street, city, region, country, landmark, 
                is_default, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$userId, $fullName, $phone, $street, $city, $region, $country, $landmark, $isDefault]);
        $newAddressId = $conn->lastInsertId();
        
        $conn->commit();
        
        // Fetch the new address
        $stmt = $conn->prepare("SELECT * FROM addresses WHERE id = ?");
        $stmt->execute([$newAddressId]);
        $newAddress = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Return success with address data
        echo json_encode([
            'success' => true, 
            'message' => 'Address saved successfully!',
            'address' => $newAddress,
            'address_type' => $addressType,
            'address_id' => $newAddressId
        ], JSON_UNESCAPED_UNICODE);
        exit;
        
    } catch (Exception $e) {
        $conn->rollBack();
        error_log("Address Save Error: " . $e->getMessage());
        error_log("Address Save Error Trace: " . $e->getTraceAsString());
        echo json_encode([
            'success' => false, 
            'message' => 'Failed to save address: ' . $e->getMessage()
        ]);
        exit;
    }
}

// Calculate volumetric weight (dimensional weight)
// Formula: (Length × Width × Height) / Dimensional Factor
// Common dimensional factors: 139 (UPS/FedEx domestic), 166 (USPS), 5000 (international metric)
function calculateVolumetricWeight($length, $width, $height, $dimensionalFactor = 5000) {
    if ($length <= 0 || $width <= 0 || $height <= 0) {
        return 0;
    }
    return ($length * $width * $height) / $dimensionalFactor;
}

// Helper function to calculate shipping cost
function calculateShippingCost($method, $weight, $length, $width, $height, $pickupCountry, $deliveryCountry, $shippingSettings) {
    global $calculateVolumetricWeight;
    
    // Get dimensional factor from settings
    $dimensionalFactor = floatval($shippingSettings['dimensional_factor'] ?? 5000);
    
    // Calculate volumetric weight if dimensions provided
    $volumetricWeight = 0;
    $usedVolumetric = false;
    if ($length > 0 && $width > 0 && $height > 0) {
        $volumetricWeight = calculateVolumetricWeight($length, $width, $height, $dimensionalFactor);
        // Use the greater of actual weight or volumetric weight
        if ($volumetricWeight > $weight) {
            $weight = $volumetricWeight;
            $usedVolumetric = true;
        }
    }
    
    $basePrice = floatval($method['base_price']);
    $perKgPrice = floatval($method['per_kg_price']);
    $weightPrice = ($weight - 1) * $perKgPrice; // First kg included in base
    if ($weightPrice < 0) $weightPrice = 0;
    
    $calculatedPrice = $basePrice + $weightPrice;
    
    // Apply overseas surcharge if international
    if ($pickupCountry !== $deliveryCountry) {
        $overseasSurcharge = floatval($shippingSettings['overseas_surcharge'] ?? 15) / 100;
        $calculatedPrice = $calculatedPrice * (1 + $overseasSurcharge);
    }
    
    // Add fuel surcharge if enabled
    if (!empty($shippingSettings['fuel_surcharge_enabled']) && $shippingSettings['fuel_surcharge_enabled'] == '1') {
        $fuelSurcharge = floatval($shippingSettings['fuel_surcharge_rate'] ?? 3) / 100;
        $calculatedPrice = $calculatedPrice * (1 + $fuelSurcharge);
    }
    
    return [
        'price' => $calculatedPrice,
        'weight' => $weight,
        'volumetric_weight' => $volumetricWeight,
        'used_volumetric' => $usedVolumetric
    ];
}

// Calculate price for predefined method or custom calculation
$calculationType = sanitize($_POST['calculation_type'] ?? $_GET['calc_type'] ?? 'predefined');
$selectedMethod = null;
$calculatedPrice = 0;
$calculatedWeight = 0;
$calculatedVolumetricWeight = 0;
$usedVolumetric = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['calculate'])) {
    // CSRF token check (skip for calculate action to allow auto-calculation)
    // The main form submission (book action) will have CSRF check
    
    // Get pickup and delivery countries from selected addresses
    $pickupAddressId = intval($_POST['pickup_address_id'] ?? 0);
    $deliveryAddressId = intval($_POST['delivery_address_id'] ?? 0);
    
    $pickupCountry = 'Ghana';
    $deliveryCountry = 'Ghana';
    
    if ($pickupAddressId > 0) {
        $stmt = $conn->prepare("SELECT country FROM addresses WHERE id = ? AND user_id = ?");
        $stmt->execute([$pickupAddressId, $userId]);
        $pickupAddr = $stmt->fetch();
        if ($pickupAddr) {
            $pickupCountry = $pickupAddr['country'] ?? 'Ghana';
        }
    }
    
    if ($deliveryAddressId > 0) {
        $stmt = $conn->prepare("SELECT country FROM addresses WHERE id = ? AND user_id = ?");
        $stmt->execute([$deliveryAddressId, $userId]);
        $deliveryAddr = $stmt->fetch();
        if ($deliveryAddr) {
            $deliveryCountry = $deliveryAddr['country'] ?? 'Ghana';
        }
    }
    
    $calculationType = sanitize($_POST['calculation_type'] ?? 'predefined');
    
    // Get shipping method ID - could be from either dropdown
    $shippingMethodId = intval($_POST['shipping_method_id'] ?? 0);
    if ($shippingMethodId <= 0) {
        // Try custom dropdown
        $shippingMethodId = intval($_POST['shipping_method_id_custom'] ?? 0);
    }
    
    if ($shippingMethodId <= 0) {
        $errors[] = 'Please select a shipping method.';
    }
    
    if ($pickupAddressId <= 0 || $deliveryAddressId <= 0) {
        $errors[] = 'Please select both pickup and delivery addresses.';
    }
    
    if (empty($errors)) {
        $method = null;
        foreach ($shippingMethods as $m) {
            if ($m['id'] == $shippingMethodId) {
                $method = $m;
                break;
            }
        }
        
        if ($method) {
            if ($calculationType === 'custom') {
                // Custom calculation - use weight and dimensions
    $weight = floatval($_POST['weight'] ?? 0);
                $length = floatval($_POST['length'] ?? 0);
                $width = floatval($_POST['width'] ?? 0);
                $height = floatval($_POST['height'] ?? 0);
    
    if ($weight <= 0) {
                    $errors[] = 'Please enter a valid weight for custom calculation.';
                } else {
                    $result = calculateShippingCost($method, $weight, $length, $width, $height, $pickupCountry, $deliveryCountry, $shippingSettings);
                    $calculatedPrice = $result['price'];
                    $calculatedWeight = $result['weight'];
                    $calculatedVolumetricWeight = $result['volumetric_weight'];
                    $usedVolumetric = $result['used_volumetric'];
                    $selectedMethod = $method;
                }
            } else {
                // Predefined - use standard weight (1kg) or calculate if weight provided
                $weight = floatval($_POST['weight'] ?? 1);
                $length = floatval($_POST['length'] ?? 0);
                $width = floatval($_POST['width'] ?? 0);
                $height = floatval($_POST['height'] ?? 0);
                
                if ($weight <= 0) $weight = 1; // Default to 1kg for predefined
                
                $result = calculateShippingCost($method, $weight, $length, $width, $height, $pickupCountry, $deliveryCountry, $shippingSettings);
                $calculatedPrice = $result['price'];
                $calculatedWeight = $result['weight'];
                $calculatedVolumetricWeight = $result['volumetric_weight'];
                $usedVolumetric = $result['used_volumetric'];
                $selectedMethod = $method;
            }
        }
    }
}

// Auto-calculate for predefined method when selected (AJAX or on page load if method is selected)
$autoSelectedMethodId = intval($_GET['method_id'] ?? $_POST['auto_calc_method_id'] ?? 0);
if ($autoSelectedMethodId > 0 && empty($calculatedPrice)) {
    foreach ($shippingMethods as $m) {
        if ($m['id'] == $autoSelectedMethodId) {
            $pickupAddressId = intval($_GET['pickup_id'] ?? $_POST['pickup_address_id'] ?? 0);
            $deliveryAddressId = intval($_GET['delivery_id'] ?? $_POST['delivery_address_id'] ?? 0);
            
            $pickupCountry = 'Ghana';
            $deliveryCountry = 'Ghana';
            
            if ($pickupAddressId > 0) {
                $stmt = $conn->prepare("SELECT country FROM addresses WHERE id = ? AND user_id = ?");
                $stmt->execute([$pickupAddressId, $userId]);
                $pickupAddr = $stmt->fetch();
                if ($pickupAddr) $pickupCountry = $pickupAddr['country'] ?? 'Ghana';
            }
            
            if ($deliveryAddressId > 0) {
                $stmt = $conn->prepare("SELECT country FROM addresses WHERE id = ? AND user_id = ?");
                $stmt->execute([$deliveryAddressId, $userId]);
                $deliveryAddr = $stmt->fetch();
                if ($deliveryAddr) $deliveryCountry = $deliveryAddr['country'] ?? 'Ghana';
            }
            
            $weight = 1; // Default weight for predefined
            $result = calculateShippingCost($m, $weight, 0, 0, 0, $pickupCountry, $deliveryCountry, $shippingSettings);
            $calculatedPrice = $result['price'];
            $calculatedWeight = $result['weight'];
            $selectedMethod = $m;
            $calculationType = 'predefined';
                break;
        }
    }
}

// Also check if we have a selected method from POST/GET but no calculated price yet (for predefined)
// Check both calculation types
$postCalculationType = sanitize($_POST['calculation_type'] ?? $_GET['calculation_type'] ?? 'predefined');

// Check for selected method from POST, GET, or from the dropdown's selected value
$shippingMethodId = intval($_POST['shipping_method_id'] ?? $_GET['shipping_method_id'] ?? 0);
if ($shippingMethodId <= 0) {
    $shippingMethodId = intval($_POST['shipping_method_id_custom'] ?? $_GET['shipping_method_id_custom'] ?? 0);
}

// Debug logging
error_log("Auto-calculation check: methodId=$shippingMethodId, calcType=$postCalculationType, calculatedPrice=$calculatedPrice, POST=" . json_encode($_POST));

if (empty($calculatedPrice) && $shippingMethodId > 0 && $postCalculationType === 'predefined') {
    error_log("Attempting auto-calculation for method ID: $shippingMethodId");
    foreach ($shippingMethods as $m) {
        if ($m['id'] == $shippingMethodId) {
            $pickupAddressId = intval($_POST['pickup_address_id'] ?? $_GET['pickup_address_id'] ?? 0);
            $deliveryAddressId = intval($_POST['delivery_address_id'] ?? $_GET['delivery_address_id'] ?? 0);
            
            // If no addresses in POST, try to get from radio buttons
            if ($pickupAddressId <= 0 && isset($_POST['pickup_address_radio'])) {
                $pickupAddressId = intval($_POST['pickup_address_radio']);
            }
            if ($deliveryAddressId <= 0 && isset($_POST['delivery_address_radio'])) {
                $deliveryAddressId = intval($_POST['delivery_address_radio']);
            }
            
            $pickupCountry = 'Ghana';
            $deliveryCountry = 'Ghana';
            
            // Get countries from addresses if available
            if ($pickupAddressId > 0) {
                $stmt = $conn->prepare("SELECT country FROM addresses WHERE id = ? AND user_id = ?");
                $stmt->execute([$pickupAddressId, $userId]);
                $pickupAddr = $stmt->fetch();
                if ($pickupAddr) $pickupCountry = $pickupAddr['country'] ?? 'Ghana';
            }
            
            if ($deliveryAddressId > 0) {
                $stmt = $conn->prepare("SELECT country FROM addresses WHERE id = ? AND user_id = ?");
                $stmt->execute([$deliveryAddressId, $userId]);
                $deliveryAddr = $stmt->fetch();
                if ($deliveryAddr) $deliveryCountry = $deliveryAddr['country'] ?? 'Ghana';
            }
            
            // Calculate price even if addresses aren't selected (use default countries)
            $weight = 1; // Default weight for predefined
            $result = calculateShippingCost($m, $weight, 0, 0, 0, $pickupCountry, $deliveryCountry, $shippingSettings);
            $calculatedPrice = $result['price'];
            $calculatedWeight = $result['weight'];
            $selectedMethod = $m;
            $calculationType = 'predefined';
            error_log("Calculation successful: price=$calculatedPrice, method=" . $m['method_name']);
            break;
        }
    }
}

// Process Ship Now (new functionality)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ship_now'])) {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid security token.';
    } else {
        $forwardingWarehouseId = intval($_POST['forwarding_warehouse_id'] ?? 0);
        $destinationWarehouseId = intval($_POST['destination_warehouse_id'] ?? 0);
        $shippingMethodType = sanitize($_POST['shipping_method_type'] ?? '');
        $shippingRateId = sanitize($_POST['shipping_rate_id'] ?? '');
        $trackingNumber = sanitize($_POST['tracking_number'] ?? '');
        $declareProducts = isset($_POST['declare_products']) ? 1 : 0;
        
        // Validate required fields
        if ($forwardingWarehouseId <= 0) {
            $errors[] = 'Please select a forwarding warehouse.';
        }
        if ($destinationWarehouseId <= 0) {
            $errors[] = 'Please select a destination warehouse.';
        }
        if (empty($shippingMethodType) || !in_array($shippingMethodType, ['air', 'sea'])) {
            $errors[] = 'Please select a shipping method (Air or Sea).';
        }
        if (empty($shippingRateId)) {
            $errors[] = 'Please select a shipping rate.';
        }
        if (empty($trackingNumber)) {
            $errors[] = 'Please enter a tracking number.';
        }
        
        // Get weight (default to 1 if not provided)
        $weight = floatval($_POST['weight'] ?? 1.0);
        if ($weight <= 0) {
            $weight = 1.0; // Default to 1 kg
        }
        
        // Payment method is now always COD (Cash on Delivery)
        $paymentMethod = 'cod';
        
        // Calculate cost based on selected rate
        $totalPrice = 0;
        if (empty($errors)) {
            // Get rate details from database
            try {
                $stmt = $conn->prepare("SELECT * FROM shipping_rates WHERE method_type = ? AND rate_id = ? AND is_active = 1");
                $stmt->execute([$shippingMethodType, $shippingRateId]);
                $rateDetails = $stmt->fetch();
                
                if ($rateDetails) {
                    if ($rateDetails['rate_type'] === 'cbm') {
                        // Sea freight - per CBM (assume 1 CBM for now)
                        $cbm = 1.0;
                        $totalPrice = floatval($rateDetails['rate_value']) * $cbm;
                    } else if ($rateDetails['rate_type'] === 'kg') {
                        // Air freight - per kg
                        $totalPrice = floatval($rateDetails['rate_value']) * $weight;
                    } else if ($rateDetails['rate_type'] === 'unit') {
                        // Per unit (e.g., phone)
                        $quantity = 1; // Default
                        $totalPrice = floatval($rateDetails['rate_value']) * $quantity;
                    }
                } else {
                    $errors[] = 'Selected shipping rate not found or inactive.';
                }
            } catch (PDOException $e) {
                error_log("Error calculating price: " . $e->getMessage());
                $errors[] = 'Error calculating shipping cost. Please try again.';
            }
        }
        
        // Validate product declaration if enabled
        $productDeclaration = null;
        if ($declareProducts) {
            $products = [];
            if (isset($_POST['product_name']) && is_array($_POST['product_name'])) {
                foreach ($_POST['product_name'] as $index => $name) {
                    if (!empty($name)) {
                        $products[] = [
                            'name' => sanitize($name),
                            'quantity' => intval($_POST['product_quantity'][$index] ?? 1),
                            'value' => floatval($_POST['product_value'][$index] ?? 0)
                        ];
                    }
                }
            }
            if (!empty($products)) {
                $productDeclaration = json_encode($products, JSON_UNESCAPED_UNICODE);
            }
        }
        
        if (empty($errors)) {
            // Store in session and redirect to ship-now process page
            $_SESSION['ship_now_data'] = [
                'forwarding_warehouse_id' => $forwardingWarehouseId,
                'destination_warehouse_id' => $destinationWarehouseId,
                'shipping_method_type' => $shippingMethodType,
                'shipping_rate_id' => $shippingRateId,
                'tracking_number' => $trackingNumber,
                'weight' => $weight,
                'total_price' => $totalPrice,
                'payment_method' => 'cod', // Always Cash on Delivery
                'product_declaration' => $productDeclaration
            ];
            
            redirect('/modules/logistics/ship-now/process.php', '', '');
        }
    }
}

// Process booking (old functionality - keep for backward compatibility)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book'])) {
    if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
        $errors[] = 'Invalid security token.';
    } else {
        $pickupAddressId = intval($_POST['pickup_address_id'] ?? 0);
        $deliveryAddressId = intval($_POST['delivery_address_id'] ?? 0);
        
        // If hidden inputs are empty, try to get from radio buttons (addresses might be selected via radio)
        if ($pickupAddressId <= 0 && isset($_POST['pickup_address_radio'])) {
            $pickupAddressId = intval($_POST['pickup_address_radio']);
            error_log("Got pickup address from radio button: " . $pickupAddressId);
        }
        
        if ($deliveryAddressId <= 0 && isset($_POST['delivery_address_radio'])) {
            $deliveryAddressId = intval($_POST['delivery_address_radio']);
            error_log("Got delivery address from radio button: " . $deliveryAddressId);
        }
        
        // Get weight and dimensions based on calculation type
        $calculationType = sanitize($_POST['calculation_type'] ?? 'predefined');
        if ($calculationType === 'custom') {
        $weight = floatval($_POST['weight'] ?? 0);
            $length = floatval($_POST['length'] ?? 0);
            $width = floatval($_POST['width'] ?? 0);
            $height = floatval($_POST['height'] ?? 0);
            $dimensions = ($length > 0 && $width > 0 && $height > 0) ? $length . 'x' . $width . 'x' . $height : '';
        } else {
            $weight = 1; // Default weight for predefined
            $dimensions = '';
        }
        
        $shippingMethodId = intval($_POST['shipping_method_id'] ?? 0);
        $paymentMethod = sanitize($_POST['payment_method'] ?? '');
        $codAmount = floatval($_POST['cod_amount'] ?? 0);
        $pickupDate = sanitize($_POST['pickup_date'] ?? '');
        $pickupTimeSlot = sanitize($_POST['pickup_time_slot'] ?? '');
        
        error_log("Book validation - Pickup ID: " . $pickupAddressId . ", Delivery ID: " . $deliveryAddressId);
        
        if ($pickupAddressId <= 0 || $deliveryAddressId <= 0) {
            $errors[] = 'Please select pickup and delivery addresses.';
            error_log("Validation failed - Pickup: " . $pickupAddressId . ", Delivery: " . $deliveryAddressId);
        }
        
        // Only validate weight for custom calculation
        if ($calculationType === 'custom' && $weight <= 0) {
            $errors[] = 'Please enter a valid weight for custom calculation.';
        }
        
        // Check shipping method - could be from either dropdown
        if ($shippingMethodId <= 0) {
            // Try to get from custom dropdown if predefined is empty
            $shippingMethodId = intval($_POST['shipping_method_id_custom'] ?? 0);
        }
        
        if ($shippingMethodId <= 0) {
            $errors[] = 'Please select a shipping method.';
        }
        
        if (empty($paymentMethod)) {
            $errors[] = 'Please select a payment method.';
        }
        
        // Check if price is calculated (optional but recommended)
        if (empty($errors) && $calculatedPrice <= 0) {
            // Price might not be calculated yet, but we can still proceed if method is selected
            // The price will be calculated in process.php
        }
        
        if (empty($errors)) {
            // Store booking data in session for process.php
            $_SESSION['booking_data'] = [
                'pickup_address_id' => $pickupAddressId,
                'delivery_address_id' => $deliveryAddressId,
                'weight' => $weight,
                'dimensions' => $dimensions,
                'shipping_method_id' => $shippingMethodId,
                'payment_method' => $paymentMethod,
                'cod_amount' => $codAmount,
                'pickup_date' => $pickupDate,
                'pickup_time_slot' => $pickupTimeSlot,
                'calculation_type' => $calculationType
            ];
            redirect('/modules/logistics/booking/process.php', '', '');
        }
    }
}

// Prepare content for layout
ob_start();
?>
<div class="page-title-section">
    <h1 class="page-title">Warehouses</h1>
    <p class="text-muted">Forward your packages from China to Ghana</p>
</div>

    <div class="row justify-content-center">
        <div class="col-lg-10">
            <?php if (!empty($errors)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <strong><i class="fas fa-exclamation-triangle me-2"></i>Error:</strong>
                <ul class="mb-0 mt-2">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
        
        <!-- Warehouse Address Display -->
        <?php if (!empty($forwardingWarehouses)): ?>
        <div class="card mb-4 shadow-sm border-0" style="border-radius: 12px; overflow: hidden;">
            <div class="card-header bg-primary text-white" style="border: none; padding: 1.5rem;">
                <h5 class="mb-0 d-flex align-items-center">
                    <i class="fas fa-warehouse me-2" style="font-size: 1.5rem;"></i>
                    <span>Forwarding Warehouse Address</span>
                </h5>
                            </div>
            <div class="card-body p-4">
                <div class="alert alert-info mb-4 border-0 shadow-sm" style="background: #e7f3ff; border-left: 4px solid #0dcaf0; border-radius: 8px;">
                    <div class="d-flex align-items-start">
                        <i class="fas fa-info-circle me-3 mt-1" style="font-size: 1.2rem; color: #0dcaf0;"></i>
                        <div>
                            <strong style="color: #05203e;">Important:</strong>
                            <p class="mb-0 mt-1" style="color: #495057;">Please copy the address below exactly and give it to your supplier or paste it directly in the e-commerce app without editing. Any changes may cause delivery issues.</p>
                                                </div>
                                                            </div>
                                    </div>
                                    
                <?php foreach ($forwardingWarehouses as $warehouse): ?>
                <div class="warehouse-address-card mb-4 p-4 border rounded-3 shadow-sm" 
                     data-warehouse-id="<?php echo $warehouse['id']; ?>"
                     style="background: #ffffff; border: 1px solid #e9ecef !important; transition: all 0.3s ease;">
                    <div class="d-flex justify-content-between align-items-start mb-3 pb-3 border-bottom">
                        <h6 class="mb-0 fw-bold d-flex align-items-center" style="color: #05203e; font-size: 1.1rem;">
                            <i class="fas fa-building me-2 text-primary"></i>
                            <?php echo htmlspecialchars($warehouse['warehouse_name']); ?>
                        </h6>
                        <button type="button" class="btn btn-primary btn-sm copy-address-btn" 
                                style="border: none; border-radius: 8px; padding: 0.5rem 1rem; font-weight: 600; transition: all 0.3s ease;"
                                data-english-address="<?php echo htmlspecialchars($warehouse['address_english']); ?>"
                                data-chinese-address="<?php echo htmlspecialchars($warehouse['address_chinese']); ?>"
                                data-receiver="<?php echo htmlspecialchars($warehouse['receiver_name'] . ' (' . ($user['user_identifier'] ?? 'Not assigned') . ')'); ?>"
                                data-phone="<?php echo htmlspecialchars($warehouse['receiver_phone']); ?>"
                                onmouseover="this.style.opacity='0.9'; this.style.transform='translateY(-1px)'"
                                onmouseout="this.style.opacity='1'; this.style.transform='translateY(0)'">
                            <i class="fas fa-copy me-1"></i>COPY ADDRESS
                        </button>
                                                </div>
                                                
                    <div class="address-details">
                        <div class="row mb-3">
                            <div class="col-sm-3 fw-semibold d-flex align-items-center text-muted">
                                <i class="fas fa-warehouse me-2 text-primary"></i>Warehouse Name:
                                                </div>
                            <div class="col-sm-9 fw-medium" style="color: #05203e;"><?php echo htmlspecialchars($warehouse['warehouse_name']); ?></div>
                                                </div>
                        <div class="row mb-3">
                            <div class="col-sm-3 fw-semibold d-flex align-items-center text-muted">
                                <i class="fas fa-user me-2 text-primary"></i>Receiver:
                                                    </div>
                            <div class="col-sm-9 fw-medium" style="color: #05203e;">
                                <?php echo htmlspecialchars($warehouse['receiver_name']); ?> 
                                <span class="badge bg-primary ms-2"><?php echo htmlspecialchars($user['user_identifier'] ?? 'Not assigned'); ?></span>
                                                    </div>
                                                </div>
                        <div class="row mb-3">
                            <div class="col-sm-3 fw-semibold d-flex align-items-center text-muted">
                                <i class="fas fa-map-marker-alt me-2 text-danger"></i>Address:
                                                </div>
                            <div class="col-sm-9 fw-medium" style="color: #05203e;"><?php echo htmlspecialchars($warehouse['address_english']); ?></div>
                                                </div>
                        <?php if (!empty($warehouse['district'])): ?>
                        <div class="row mb-3">
                            <div class="col-sm-3 fw-semibold d-flex align-items-center text-muted">
                                <i class="fas fa-map me-2 text-info"></i>District:
                                                </div>
                            <div class="col-sm-9 fw-medium" style="color: #05203e;"><?php echo htmlspecialchars($warehouse['district']); ?></div>
                                                </div>
                                        <?php endif; ?>
                        <div class="row mb-3">
                            <div class="col-sm-3 fw-semibold d-flex align-items-center text-muted">
                                <i class="fas fa-city me-2 text-info"></i>City:
                                    </div>
                            <div class="col-sm-9 fw-medium" style="color: #05203e;"><?php echo htmlspecialchars($warehouse['city']); ?></div>
                                </div>
                        <div class="row mb-3">
                            <div class="col-sm-3 fw-semibold d-flex align-items-center text-muted">
                                <i class="fas fa-globe me-2 text-success"></i>Country:
                                                </div>
                            <div class="col-sm-9 fw-medium" style="color: #05203e;"><?php echo htmlspecialchars($warehouse['country']); ?></div>
                                                </div>
                        <div class="row mb-0">
                            <div class="col-sm-3 fw-semibold d-flex align-items-center text-muted">
                                <i class="fas fa-phone me-2 text-success"></i>Phone Number:
                                                    </div>
                            <div class="col-sm-9 fw-medium" style="color: #05203e;"><?php echo htmlspecialchars($warehouse['receiver_phone']); ?></div>
                                                    </div>
                                                </div>
                                                </div>
                <?php endforeach; ?>
                                                </div>
                                                </div>
        <?php endif; ?>
        
        <!-- Ship Now Form -->
        <div class="card mb-4 shadow-sm border-0" style="border-radius: 12px; overflow: hidden;">
            <div class="card-header bg-primary text-white" style="border: none; padding: 1.5rem;">
                <h5 class="mb-0 d-flex align-items-center">
                    <i class="fas fa-shipping-fast me-2" style="font-size: 1.5rem;"></i>
                    <span>Ship Now</span>
                </h5>
                                            </div>
            <div class="card-body p-4" style="background: #ffffff;">
                <form method="POST" action="" id="shipNowForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    
                    <!-- Forwarding Warehouse Selection -->
                    <div class="mb-4">
                        <label class="form-label fw-bold d-flex align-items-center mb-2" style="color: #05203e; font-size: 1rem;">
                            <i class="fas fa-warehouse me-2 text-primary"></i>
                            Forwarding Warehouse <span class="text-danger ms-1">*</span>
                                    </label>
                        <select name="forwarding_warehouse_id" id="forwarding_warehouse_id" 
                                class="form-select form-select-lg" 
                                style="border-radius: 8px; border: 1px solid #dee2e6; padding: 0.75rem 1rem; transition: all 0.3s ease;"
                                onfocus="this.style.borderColor='#05203e'; this.style.boxShadow='0 0 0 0.2rem rgba(5, 32, 62, 0.15)'"
                                onblur="this.style.borderColor='#dee2e6'; this.style.boxShadow='none'"
                                required>
                            <option value="">-- Select Forwarding Warehouse --</option>
                            <?php foreach ($forwardingWarehouses as $warehouse): ?>
                            <option value="<?php echo $warehouse['id']; ?>">
                                <?php echo htmlspecialchars($warehouse['warehouse_name'] . ' - ' . $warehouse['city'] . ', ' . $warehouse['country']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="form-text text-muted mt-2 d-flex align-items-center">
                            <i class="fas fa-info-circle me-1"></i>
                            Select the warehouse where your supplier will send the package
                                </small>
                                    </div>
                                    
                    <!-- Destination Warehouse Selection -->
                    <div class="mb-4">
                        <label class="form-label fw-bold d-flex align-items-center mb-2" style="color: #05203e; font-size: 1rem;">
                            <i class="fas fa-map-marker-alt me-2 text-danger"></i>
                            Destination Warehouse <span class="text-danger ms-1">*</span>
                        </label>
                        <select name="destination_warehouse_id" id="destination_warehouse_id" 
                                class="form-select form-select-lg" 
                                style="border-radius: 8px; border: 1px solid #dee2e6; padding: 0.75rem 1rem; transition: all 0.3s ease;"
                                onfocus="this.style.borderColor='#05203e'; this.style.boxShadow='0 0 0 0.2rem rgba(5, 32, 62, 0.15)'"
                                onblur="this.style.borderColor='#dee2e6'; this.style.boxShadow='none'"
                                required>
                            <option value="">-- Select Destination Warehouse --</option>
                            <?php foreach ($destinationWarehouses as $warehouse): ?>
                            <option value="<?php echo $warehouse['id']; ?>">
                                <?php echo htmlspecialchars($warehouse['warehouse_name'] . ' - ' . $warehouse['city'] . ', ' . $warehouse['country']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                        <small class="form-text text-muted mt-2 d-flex align-items-center">
                            <i class="fas fa-info-circle me-1"></i>
                            Select where you want to pick up your package
                        </small>
                                    </div>
                                    
                    <!-- Shipping Method Selection -->
                    <div class="mb-4">
                        <label class="form-label fw-bold d-flex align-items-center mb-2" style="color: #05203e; font-size: 1rem;">
                            <i class="fas fa-truck me-2 text-info"></i>
                            Shipping Method <span class="text-danger ms-1">*</span>
                        </label>
                        <select name="shipping_method_type" id="shipping_method_type" 
                                class="form-select form-select-lg" 
                                style="border-radius: 8px; border: 1px solid #dee2e6; padding: 0.75rem 1rem; transition: all 0.3s ease;"
                                onfocus="this.style.borderColor='#05203e'; this.style.boxShadow='0 0 0 0.2rem rgba(5, 32, 62, 0.15)'"
                                onblur="this.style.borderColor='#dee2e6'; this.style.boxShadow='none'"
                                required>
                            <option value="">-- Select Shipping Method --</option>
                            <option value="air">✈️ Air</option>
                            <option value="sea">🚢 Sea</option>
                        </select>
                        <small class="form-text text-muted mt-2 d-flex align-items-center">
                            <i class="fas fa-info-circle me-1"></i>
                            Select Air or Sea shipping method
                        </small>
                                </div>
                                
                    <!-- Shipping Rate Selection (Dynamic) -->
                    <div class="mb-4" id="shipping_rate_section" style="display: none;">
                        <label class="form-label fw-bold d-flex align-items-center mb-2" style="color: #05203e; font-size: 1rem;">
                            <i class="fas fa-tags me-2 text-success"></i>
                            Shipping Rate <span class="text-danger ms-1">*</span>
                        </label>
                        <select name="shipping_rate_id" id="shipping_rate_id" 
                                class="form-select form-select-lg" 
                                style="border-radius: 8px; border: 1px solid #dee2e6; padding: 0.75rem 1rem; transition: all 0.3s ease;"
                                onfocus="this.style.borderColor='#05203e'; this.style.boxShadow='0 0 0 0.2rem rgba(5, 32, 62, 0.15)'"
                                onblur="this.style.borderColor='#dee2e6'; this.style.boxShadow='none'"
                                required>
                            <option value="">-- Select Rate --</option>
                                        </select>
                        <div id="rate_description" class="mt-3 p-3 rounded" style="background: #f8f9fa; border-left: 4px solid #05203e;"></div>
                                    </div>
                                    
                    <!-- Tracking Number -->
                    <div class="mb-4">
                        <label class="form-label fw-bold d-flex align-items-center mb-2" style="color: #05203e; font-size: 1rem;">
                            <i class="fas fa-barcode me-2 text-warning"></i>
                            Tracking Number <span class="text-danger ms-1">*</span>
                        </label>
                        <div class="input-group input-group-lg">
                            <input type="text" name="tracking_number" id="tracking_number" 
                                   class="form-control" 
                                   style="border-radius: 8px 0 0 8px; border: 1px solid #dee2e6; padding: 0.75rem 1rem; transition: all 0.3s ease;"
                                   onfocus="this.style.borderColor='#05203e'; this.style.boxShadow='0 0 0 0.2rem rgba(5, 32, 62, 0.15)'"
                                   onblur="this.style.borderColor='#dee2e6'; this.style.boxShadow='none'"
                                   placeholder="Enter tracking number" required>
                            <button type="button" class="btn btn-primary" 
                                    id="scan_tracking_btn" 
                                    title="Scan tracking number"
                                    style="border: none; border-radius: 0 8px 8px 0; padding: 0.75rem 1.5rem; transition: all 0.3s ease;"
                                    onmouseover="this.style.opacity='0.9'"
                                    onmouseout="this.style.opacity='1'">
                                <i class="fas fa-camera"></i>
                                </button>
                            </div>
                        <small class="form-text text-muted mt-2 d-flex align-items-center">
                            <i class="fas fa-info-circle me-1"></i>
                            Enter the tracking number from your supplier or scan it from the package
                        </small>
                        <div id="camera_modal_container"></div>
                    </div>
                    
                    <!-- Weight and Dimensions (Optional but recommended for accurate pricing) -->
                    <div class="mb-4">
                        <label class="form-label fw-bold d-flex align-items-center mb-2" style="color: #05203e; font-size: 1rem;">
                            <i class="fas fa-weight me-2 text-info"></i>
                            Package Weight (kg) <span class="text-muted ms-1">(Optional)</span>
                        </label>
                        <input type="number" name="weight" id="package_weight" 
                               class="form-control form-control-lg" 
                               style="border-radius: 8px; border: 1px solid #dee2e6; padding: 0.75rem 1rem; transition: all 0.3s ease;"
                               onfocus="this.style.borderColor='#05203e'; this.style.boxShadow='0 0 0 0.2rem rgba(5, 32, 62, 0.15)'"
                               onblur="this.style.borderColor='#dee2e6'; this.style.boxShadow='none'"
                               placeholder="Enter package weight in kg" min="0.1" step="0.1" value="1">
                        <small class="form-text text-muted mt-2 d-flex align-items-center">
                            <i class="fas fa-info-circle me-1"></i>
                            Enter the weight of your package for accurate cost calculation. Default: 1 kg
                        </small>
                    </div>
                    
                    <!-- Cost Calculation Display -->
                    <div class="mb-4 p-4 rounded" id="cost_calculation_section" style="background: #e7f3ff; border: 2px solid #05203e; border-radius: 10px; display: none;">
                        <h6 class="fw-bold d-flex align-items-center mb-3" style="color: #05203e;">
                            <i class="fas fa-calculator me-2 text-primary"></i>
                            Cost Calculation
                        </h6>
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <strong>Shipping Rate:</strong>
                                <div id="calc_rate_display" class="text-primary">-</div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <strong>Package Weight:</strong>
                                <div id="calc_weight_display">-</div>
                            </div>
                            <div class="col-md-12 mt-3 pt-3 border-top">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0 fw-bold" style="color: #05203e;">Total Cost:</h5>
                                    <h4 class="mb-0 fw-bold text-primary" id="total_cost_display">$0.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Payment Method Info (Cash on Delivery) -->
                    <div class="mb-4 p-3 rounded" style="background: #e7f3ff; border: 1px solid #b3d9ff;">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-info-circle me-2 text-primary" style="font-size: 1.2rem;"></i>
                            <div>
                                <strong class="text-primary">Payment Method:</strong>
                                <span class="ms-2">Cash on Delivery (COD) - Payment will be collected when you pick up your package.</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product Declaration Toggle -->
                    <div class="mb-4 p-4 rounded" style="background: #f8f9fa; border: 1px solid #dee2e6;">
                        <div class="form-check form-switch d-flex align-items-center">
                            <input class="form-check-input me-3" type="checkbox" name="declare_products" id="declare_products" value="1" style="width: 3rem; height: 1.5rem; cursor: pointer;">
                            <label class="form-check-label fw-bold d-flex align-items-center" for="declare_products" style="color: #05203e; font-size: 1rem; cursor: pointer;">
                                <i class="fas fa-box me-2 text-primary"></i>
                                Declare Products in Shipment <span class="badge bg-secondary ms-2">Optional</span>
                                        </label>
                                    </div>
                        <small class="form-text text-muted mt-2 ms-5 d-flex align-items-center">
                            <i class="fas fa-info-circle me-1"></i>
                            Enable this to declare products, quantities, and values
                        </small>
                                </div>
                                
                    <!-- Product Declaration Fields (Hidden by default) -->
                    <div id="product_declaration_section" style="display: none;">
                        <div class="card mb-4 border-0 shadow-sm" style="background: #ffffff; border: 1px solid #dee2e6; border-radius: 12px;">
                            <div class="card-body p-4">
                                <h6 class="card-title fw-bold d-flex align-items-center mb-4" style="color: #05203e;">
                                    <i class="fas fa-list me-2 text-primary"></i>
                                    Product Declaration
                                </h6>
                                <div id="products_list">
                                    <div class="product-item mb-3 p-3 border rounded" style="background: #f8f9fa; border: 1px solid #dee2e6 !important;">
                                        <div class="row g-3">
                                            <div class="col-md-4">
                                                <label class="form-label small fw-semibold">Product Name</label>
                                                <input type="text" name="product_name[]" class="form-control" placeholder="Product name" style="border-radius: 6px; border: 1px solid #dee2e6;">
                                    </div>
                                            <div class="col-md-3">
                                                <label class="form-label small fw-semibold">Quantity</label>
                                                <input type="number" name="product_quantity[]" class="form-control" placeholder="Qty" min="1" value="1" style="border-radius: 6px; border: 1px solid #dee2e6;">
                                </div>
                                            <div class="col-md-3">
                                                <label class="form-label small fw-semibold">Value (USD)</label>
                                                <input type="number" name="product_value[]" class="form-control" placeholder="0.00" min="0" step="0.01" value="0" style="border-radius: 6px; border: 1px solid #dee2e6;">
                            </div>
                                            <div class="col-md-2 d-flex align-items-end">
                                                <button type="button" class="btn btn-danger w-100 remove-product-btn" style="display: none; border-radius: 6px;">
                                                    <i class="fas fa-trash"></i>
                        </button>
                    </div>
                            </div>
                                </div>
                            </div>
                                <button type="button" class="btn btn-outline-primary mt-2" id="add_product_btn" style="border-radius: 8px;">
                                    <i class="fas fa-plus me-1"></i>Add Product
                                </button>
                        </div>
                    </div>
                </div>
                    
                    <!-- Submit Button -->
                    <div class="d-grid mt-4">
                        <button type="submit" name="ship_now" 
                                class="btn btn-primary btn-lg fw-bold" 
                                style="border: none; border-radius: 10px; padding: 1rem 2rem; font-size: 1.1rem; transition: all 0.3s ease;"
                                onmouseover="this.style.opacity='0.9'; this.style.transform='translateY(-2px)'"
                                onmouseout="this.style.opacity='1'; this.style.transform='translateY(0)'">
                            <i class="fas fa-paper-plane me-2"></i>Ship Now
                        </button>
        </div>
                </form>
                            </div>
                        </div>
    </div>
</div>

<?php
$content = ob_get_clean();

// JavaScript for dynamic functionality
// Add QuaggaJS for barcode scanning
$additionalCSS = [
    'https://cdnjs.cloudflare.com/ajax/libs/quagga/0.12.1/quagga.min.css'
];

$additionalJS = [
    'https://cdnjs.cloudflare.com/ajax/libs/quagga/0.12.1/quagga.min.js'
];

$inlineJS = '
// Shipping rates data
const shippingRates = ' . json_encode($shippingRates, JSON_UNESCAPED_UNICODE) . ';

// Handle shipping method change
document.getElementById("shipping_method_type").addEventListener("change", function() {
    const methodType = this.value;
        const rateSection = document.getElementById("shipping_rate_section");
        const rateSelect = document.getElementById("shipping_rate_id");
        const rateDescription = document.getElementById("rate_description");
        
        if (methodType && shippingRates[methodType]) {
            rateSection.style.display = "block";
            rateSelect.innerHTML = "<option value=\"\">-- Select Rate --</option>";
            rateSelect.required = true;
            
            shippingRates[methodType].forEach(rate => {
                const option = document.createElement("option");
                option.value = rate.id;
                option.textContent = rate.name + " - " + rate.rate + " (" + rate.duration + ")";
                option.dataset.description = rate.description;
                rateSelect.appendChild(option);
            });
            
            rateDescription.textContent = "";
        } else {
            rateSection.style.display = "none";
            rateSelect.required = false;
            rateDescription.textContent = "";
            document.getElementById("cost_calculation_section").style.display = "none";
        }
        calculateCost();
    });

// Function to calculate and display cost
function calculateCost() {
    const methodType = document.getElementById("shipping_method_type").value;
    const rateId = document.getElementById("shipping_rate_id").value;
    const weight = parseFloat(document.getElementById("package_weight").value) || 1;
    const costSection = document.getElementById("cost_calculation_section");
    const calcRateDisplay = document.getElementById("calc_rate_display");
    const calcWeightDisplay = document.getElementById("calc_weight_display");
    const totalCostDisplay = document.getElementById("total_cost_display");
    
    if (methodType && rateId && shippingRates[methodType]) {
        const rate = shippingRates[methodType].find(r => r.id === rateId);
        if (rate) {
            let totalCost = 0;
            let displayText = rate.name + " - " + rate.rate;
            
            if (rate.rate_type === "cbm") {
                // Sea freight - per CBM (assume 1 CBM for now)
                const cbm = 1.0;
                totalCost = rate.rate_value * cbm;
                displayText += " (1 CBM)";
            } else if (rate.rate_type === "kg") {
                // Air freight - per kg
                totalCost = rate.rate_value * weight;
                displayText += " × " + weight + " kg";
            } else if (rate.rate_type === "unit") {
                // Per unit (e.g., phone)
                const quantity = 1; // Default
                totalCost = rate.rate_value * quantity;
                displayText += " (1 unit)";
            }
            
            // Display calculation
            calcRateDisplay.textContent = displayText;
            calcWeightDisplay.textContent = weight + " kg";
            totalCostDisplay.textContent = "$" + totalCost.toFixed(2);
            costSection.style.display = "block";
        } else {
            costSection.style.display = "none";
        }
    } else {
        costSection.style.display = "none";
    }
}

// Handle rate selection change
document.getElementById("shipping_rate_id").addEventListener("change", function() {
    const selectedOption = this.options[this.selectedIndex];
    const description = document.getElementById("rate_description");
    if (selectedOption.dataset.description) {
        description.textContent = selectedOption.dataset.description;
    } else {
        description.textContent = "";
    }
    calculateCost();
});

// Handle weight change
document.getElementById("package_weight").addEventListener("input", function() {
    calculateCost();
});

// Copy address functionality
document.querySelectorAll(".copy-address-btn").forEach(btn => {
    btn.addEventListener("click", function() {
        const chineseAddress = this.dataset.chineseAddress;
        const receiver = this.dataset.receiver;
        const phone = this.dataset.phone;
        
        // Format address for copying (Chinese version)
        const addressText = receiver + "\\n" + chineseAddress + "\\n" + phone;
        
        // Copy to clipboard
        navigator.clipboard.writeText(addressText).then(() => {
            const originalText = this.innerHTML;
            this.innerHTML = "<i class=\"fas fa-check me-1\"></i>COPIED!";
            this.classList.remove("btn-primary");
            this.classList.add("btn-success");
            
            setTimeout(() => {
                this.innerHTML = originalText;
                this.classList.remove("btn-success");
                this.classList.add("btn-primary");
            }, 2000);
        }).catch(err => {
            alert("Failed to copy address. Please copy manually.");
            console.error("Copy error:", err);
        });
    });
});

// Product declaration toggle
document.getElementById("declare_products").addEventListener("change", function() {
    const section = document.getElementById("product_declaration_section");
    if (this.checked) {
        section.style.display = "block";
    } else {
        section.style.display = "none";
    }
});

// Add product button
document.getElementById("add_product_btn").addEventListener("click", function() {
    const productsList = document.getElementById("products_list");
    const newProduct = document.createElement("div");
    newProduct.className = "product-item mb-3 p-3 border rounded";
    newProduct.style.cssText = "background: #f8f9fa; border: 1px solid #dee2e6 !important;";
    newProduct.innerHTML = `
        <div class="row g-3">
            <div class="col-md-4">
                <label class="form-label small fw-semibold">Product Name</label>
                <input type="text" name="product_name[]" class="form-control" placeholder="Product name" style="border-radius: 6px; border: 1px solid #dee2e6;">
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-semibold">Quantity</label>
                <input type="number" name="product_quantity[]" class="form-control" placeholder="Qty" min="1" value="1" style="border-radius: 6px; border: 1px solid #dee2e6;">
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-semibold">Value (GHS)</label>
                <input type="number" name="product_value[]" class="form-control" placeholder="0.00" min="0" step="0.01" value="0" style="border-radius: 6px; border: 1px solid #dee2e6;">
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="button" class="btn btn-danger w-100 remove-product-btn" style="border-radius: 6px;">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `;
    productsList.appendChild(newProduct);
    
    // Show remove buttons if more than one product
    updateRemoveButtons();
    
    // Attach remove event
    newProduct.querySelector(".remove-product-btn").addEventListener("click", function() {
        newProduct.remove();
        updateRemoveButtons();
    });
});

// Remove product functionality
function updateRemoveButtons() {
    const products = document.querySelectorAll(".product-item");
    products.forEach((product, index) => {
        const removeBtn = product.querySelector(".remove-product-btn");
        if (products.length > 1) {
            removeBtn.style.display = "block";
                } else {
            removeBtn.style.display = "none";
        }
    });
}

// Barcode scanning functionality with QuaggaJS
let cameraStream = null;
let quaggaInitialized = false;

document.getElementById("scan_tracking_btn").addEventListener("click", function() {
    if (!("mediaDevices" in navigator && "getUserMedia" in navigator.mediaDevices)) {
        alert("Camera access is not supported in your browser. Please enter the tracking number manually.");
        return;
    }
    
    // Request camera permission
    navigator.mediaDevices.getUserMedia({ 
        video: { 
            facingMode: "environment",
            width: { ideal: 1280 },
            height: { ideal: 720 }
        } 
    })
    .then(stream => {
        cameraStream = stream;
        showCameraModal();
    })
    .catch(err => {
        alert("Camera access denied. Please allow camera access to scan tracking numbers, or enter the tracking number manually.");
        console.error("Camera error:", err);
    });
});

function showCameraModal() {
    const container = document.getElementById("camera_modal_container");
    container.innerHTML = `
        <div class="modal fade show" id="cameraModal" tabindex="-1" style="display: block; z-index: 1055;" data-bs-backdrop="static">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-camera me-2"></i>Scan Tracking Number
                        </h5>
                        <button type="button" class="btn-close" onclick="closeCameraModal()"></button>
                    </div>
                    <div class="modal-body text-center">
                        <div id="scanner_container" style="position: relative; width: 100%; max-width: 640px; margin: 0 auto;">
                            <div id="interactive" style="width: 100%; height: 400px; border: 2px solid #ddd; border-radius: 8px; background: #000;"></div>
                            <div id="scan_overlay" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.8);">
                                Point camera at barcode
                            </div>
                        </div>
                        <p class="mt-3 text-muted">Position the barcode within the camera view</p>
                        <div id="scan_result" class="mt-3"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="closeCameraModal()">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                        <button type="button" class="btn btn-primary" onclick="manualEntry()">
                            <i class="fas fa-keyboard"></i> Enter Manually
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-backdrop fade show" style="z-index: 1050;"></div>
    `;
    
    // Initialize QuaggaJS
    setTimeout(() => {
        initQuagga();
    }, 100);
}

function initQuagga() {
    if (quaggaInitialized) {
        return;
    }
    
    Quagga.init({
        inputStream: {
            name: "Live",
            type: "LiveStream",
            target: document.querySelector("#interactive"),
            constraints: {
                width: 640,
                height: 480,
                facingMode: "environment"
            }
        },
        decoder: {
            readers: [
                "code_128_reader",
                "ean_reader",
                "ean_8_reader",
                "code_39_reader",
                "code_39_vin_reader",
                "codabar_reader",
                "upc_reader",
                "upc_e_reader",
                "i2of5_reader"
            ]
        },
        locate: true
    }, function(err) {
        if (err) {
            console.error("Quagga initialization error:", err);
            document.getElementById("scan_result").innerHTML = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> 
                    Scanner initialization failed. Please try entering the tracking number manually.
                </div>
            `;
            return;
        }
        
        quaggaInitialized = true;
        Quagga.start();
        
        // Listen for detection
        Quagga.onDetected(function(result) {
            const code = result.codeResult.code;
            if (code) {
                document.getElementById("tracking_number").value = code.trim();
                document.getElementById("scan_result").innerHTML = `
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> 
                        Tracking number detected: <strong>${code}</strong>
                    </div>
                `;
                
                // Auto-close after short delay
                setTimeout(() => {
                    closeCameraModal();
                }, 1500);
            }
        });
    });
}

function closeCameraModal() {
    if (quaggaInitialized) {
        Quagga.stop();
        quaggaInitialized = false;
    }
    
    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
        cameraStream = null;
    }
    
    document.getElementById("camera_modal_container").innerHTML = "";
}

function manualEntry() {
    const trackingNumber = prompt("Please enter the tracking number manually:");
    if (trackingNumber) {
        document.getElementById("tracking_number").value = trackingNumber.trim();
        closeCameraModal();
    }
}
';

// Set page title and include layout
$pageTitle = 'Warehouses - ' . APP_NAME;
include __DIR__ . '/../../../includes/layouts/user-layout.php';
?>
